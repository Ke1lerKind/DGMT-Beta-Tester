const DASHBOARD_URL = "dashboard/dashboard.html";

const DMS_STATE = {
  tabs: {},
  maxMessages: 200
};

function createEmptyTabState(tabId) {
  return {
    tabId,
    activeChannel: null,
    activeUrl: null,
    updatedAt: null,
    isModerator: false,
    authMode: "safe_mod_view_only",
    streamInfo: {
      title: "",
      game: "",
      isLive: false,
      source: "dom",
      updatedAt: null
    },
    adInfo: {
      isAdRunning: false,
      label: "No ad signal detected",
      detectedBy: "dom",
      updatedAt: null
    },
    messages: []
  };
}

function getTabState(tabId) {
  if (!tabId && tabId !== 0) return null;

  if (!DMS_STATE.tabs[tabId]) {
    DMS_STATE.tabs[tabId] = createEmptyTabState(tabId);
  }

  return DMS_STATE.tabs[tabId];
}

function broadcastToDashboard(tabId, type, payload) {
  chrome.runtime.sendMessage({
    type,
    tabId,
    payload
  });
}

function openDashboardForTab(tabId, channel = "") {
  const url = chrome.runtime.getURL(
    `${DASHBOARD_URL}?tabId=${encodeURIComponent(tabId)}&channel=${encodeURIComponent(channel || "")}`
  );

  chrome.windows.create({
    url,
    type: "popup",
    width: 580,
    height: 900
  });
}

function storeMessage(tabState, chatMessage) {
  if (tabState.messages.some((msg) => msg.id === chatMessage.id)) return;

  tabState.messages.unshift(chatMessage);

  if (tabState.messages.length > DMS_STATE.maxMessages) {
    tabState.messages.pop();
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;

  const tabState = getTabState(tab.id);
  openDashboardForTab(tab.id, tabState?.activeChannel || "");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type) return;

  const senderTabId = sender?.tab?.id;
  const requestedTabId = Number(message.tabId);
  const tabId = Number.isFinite(requestedTabId) ? requestedTabId : senderTabId;

  if (message.type === "OPEN_DASHBOARD") {
    const tabState = getTabState(tabId);
    openDashboardForTab(tabId, tabState?.activeChannel || message.payload?.channel || "");
    return;
  }

  if (message.type === "ACTIVE_CHANNEL_UPDATE") {
    const tabState = getTabState(tabId);
    if (!tabState) return;

    tabState.activeChannel = message.payload.channel;
    tabState.activeUrl = message.payload.url;
    tabState.updatedAt = message.payload.updatedAt;
    tabState.isModerator = Boolean(message.payload.isModerator);
    tabState.authMode = message.payload.authMode || "safe_mod_view_only";

    broadcastToDashboard(tabId, "DASHBOARD_ACTIVE_CHANNEL_UPDATE", tabState);
    return;
  }

  if (message.type === "STREAM_INFO_UPDATE") {
    const tabState = getTabState(tabId);
    if (!tabState) return;

    tabState.streamInfo = message.payload;
    broadcastToDashboard(tabId, "DASHBOARD_STREAM_INFO_UPDATE", tabState.streamInfo);
    return;
  }

  if (message.type === "AD_INFO_UPDATE") {
    const tabState = getTabState(tabId);
    if (!tabState) return;

    tabState.adInfo = message.payload;
    broadcastToDashboard(tabId, "DASHBOARD_AD_INFO_UPDATE", tabState.adInfo);
    return;
  }

  if (message.type === "CHAT_MESSAGE") {
    const tabState = getTabState(tabId);
    if (!tabState) return;

    storeMessage(tabState, message.payload);
    broadcastToDashboard(tabId, "DASHBOARD_CHAT_MESSAGE", message.payload);
    return;
  }

  if (message.type === "GET_DASHBOARD_STATE") {
    const tabState = getTabState(tabId);
    sendResponse(tabState || null);
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  delete DMS_STATE.tabs[tabId];
});