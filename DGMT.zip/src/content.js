console.log("[Drumgod Modsupport] Content Script loaded.");

const DMS_BUTTON_ID = "dms-launcher";
const DMS_STORAGE_POSITION_KEY = "dmsButtonPosition";
const DMS_STORAGE_DRAG_KEY = "dmsButtonDraggable";

const DMS_CHAT_STATE = {
  observedNodes: new WeakSet(),
  observedIds: new Set(),
  observer: null,
  activeAdapter: null,
  lastUrl: location.href,
  lastStreamInfoJson: "",
  lastAdInfoJson: "",
  lastCanUseTool: false
};

let isDragging = false;
let dragMoved = false;
let dragOffsetX = 0;
let dragOffsetY = 0;
let dragEnabled = true;

const DMS_AUTH = {
  async canUseTool(channel) {
    if (!channel) return false;

    if (window.DrumgodTwitchAuth) {
      return await window.DrumgodTwitchAuth.canUseTool(channel, {
        isModeratorView: isModeratorView(),
        url: window.location.href
      });
    }

    return isModeratorView();
  }
};

function getPathParts() {
  return window.location.pathname.split("/").filter(Boolean);
}

function isModeratorView() {
  return window.location.pathname.toLowerCase().startsWith("/moderator/");
}

function getCurrentTwitchChannel() {
  const pathParts = getPathParts();

  if (pathParts[0]?.toLowerCase() === "moderator" && pathParts[1]) {
    return pathParts[1].toLowerCase();
  }

  const blockedPaths = [
    "directory",
    "settings",
    "subscriptions",
    "inventory",
    "downloads",
    "jobs",
    "p",
    "turbo",
    "wallet",
    "drops",
    "store"
  ];

  const firstPath = pathParts[0]?.toLowerCase();

  if (!firstPath || blockedPaths.includes(firstPath)) {
    return null;
  }

  return firstPath;
}

function cleanText(text) {
  return String(text || "")
    .replace(/\u034f/g, "")
    .replace(/\u200b/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

async function canUseModsupport() {
  return await DMS_AUTH.canUseTool(getCurrentTwitchChannel());
}

async function sendActiveChannelToBackground() {
  const isModerator = await canUseModsupport();

  chrome.runtime.sendMessage({
    type: "ACTIVE_CHANNEL_UPDATE",
    payload: {
      channel: getCurrentTwitchChannel(),
      url: window.location.href,
      isModerator,
      authMode: window.DrumgodTwitchAuth?.mode || "safe_mod_view_only",
      updatedAt: new Date().toISOString()
    }
  });

  DMS_CHAT_STATE.lastCanUseTool = isModerator;
}

function detectStreamInfoFromDom() {
  const titleElement =
    document.querySelector("[data-a-target='player-info-title']") ||
    document.querySelector("[data-a-target='stream-title']") ||
    document.querySelector("h1");

  const gameElement =
    document.querySelector("[data-a-target='player-info-game-name']") ||
    document.querySelector("[data-a-target='stream-game-link']");

  const bodyText = document.body?.innerText || "";

  const isOffline =
    bodyText.includes("OFFLINE") ||
    bodyText.includes("is currently offline") ||
    bodyText.includes("currently offline");

  return {
    title: cleanText(titleElement?.innerText),
    game: cleanText(gameElement?.innerText),
    isLive: !isOffline,
    source: "dom",
    updatedAt: new Date().toISOString()
  };
}

async function detectStreamInfo() {
  const channel = getCurrentTwitchChannel();

  if (window.DrumgodTwitchApi?.getStreamInfo) {
    try {
      const apiStreamInfo = await window.DrumgodTwitchApi.getStreamInfo(channel);

      if (apiStreamInfo) {
        return {
          ...apiStreamInfo,
          source: "twitch-api",
          updatedAt: new Date().toISOString()
        };
      }
    } catch (error) {
      console.warn("[Drumgod Modsupport] Twitch API stream info failed:", error);
    }
  }

  return detectStreamInfoFromDom();
}

async function sendStreamInfoToBackground() {
  const streamInfo = await detectStreamInfo();
  const serialized = JSON.stringify(streamInfo);

  if (serialized === DMS_CHAT_STATE.lastStreamInfoJson) return;

  DMS_CHAT_STATE.lastStreamInfoJson = serialized;

  chrome.runtime.sendMessage({
    type: "STREAM_INFO_UPDATE",
    payload: streamInfo
  });
}

function detectAdInfoFromDom(streamInfo) {
  const adSelectors = [
    "[data-a-target='video-ad-label']",
    "[data-a-target='player-overlay-ad']",
    "[data-a-target='player-ad-overlay']",
    "[class*='video-ad']",
    "[class*='player-ad']",
    "[class*='commercial']"
  ];

  const hasAdElement = adSelectors.some((selector) => {
    try {
      return Boolean(document.querySelector(selector));
    } catch {
      return false;
    }
  });

  const bodyText = (document.body?.innerText || "").toLowerCase();

  const hasAdText =
    bodyText.includes("ad break") ||
    bodyText.includes("commercial break") ||
    bodyText.includes("advertisement") ||
    bodyText.includes("werbung läuft") ||
    bodyText.includes("anzeige läuft") ||
    bodyText.includes("ad 1 of") ||
    bodyText.includes("ad 2 of");

  const isAdRunning = Boolean(streamInfo?.isLive && (hasAdElement || hasAdText));

  return {
    isAdRunning,
    label: isAdRunning ? "Ad running" : "No ad signal detected",
    detectedBy: "dom",
    updatedAt: new Date().toISOString()
  };
}

async function detectAdInfo() {
  const channel = getCurrentTwitchChannel();

  if (window.DrumgodTwitchApi?.getAdInfo) {
    try {
      const apiAdInfo = await window.DrumgodTwitchApi.getAdInfo(channel);

      if (apiAdInfo) {
        return {
          ...apiAdInfo,
          detectedBy: "twitch-api",
          updatedAt: new Date().toISOString()
        };
      }
    } catch (error) {
      console.warn("[Drumgod Modsupport] Twitch API ad info failed:", error);
    }
  }

  const streamInfo = await detectStreamInfo();
  return detectAdInfoFromDom(streamInfo);
}

async function sendAdInfoToBackground() {
  const adInfo = await detectAdInfo();
  const serialized = JSON.stringify(adInfo);

  if (serialized === DMS_CHAT_STATE.lastAdInfoJson) return;

  DMS_CHAT_STATE.lastAdInfoJson = serialized;

  chrome.runtime.sendMessage({
    type: "AD_INFO_UPDATE",
    payload: adInfo
  });
}

async function openDashboard() {
  if (!(await canUseModsupport())) return;

  await sendActiveChannelToBackground();

  chrome.runtime.sendMessage({
    type: "OPEN_DASHBOARD",
    payload: {
      channel: getCurrentTwitchChannel()
    }
  });
}

function getLogoUrl() {
  return chrome.runtime.getURL("bilder/Browserlogo.png");
}

function removeButton() {
  document.getElementById(DMS_BUTTON_ID)?.remove();
}

function getDefaultButtonPosition() {
  return {
    x: 6,
    y: Math.floor(window.innerHeight * 0.75)
  };
}

function createButton() {
  const button = document.createElement("button");
  button.id = DMS_BUTTON_ID;
  button.type = "button";
  button.title = "Open Drumgod Modsupport";

  button.innerHTML = `
    <img src="${getLogoUrl()}" alt="Drumgod Modsupport" />
  `;

  button.addEventListener("mousedown", startDrag);
  button.addEventListener("click", handleClick);

  return button;
}

async function handleClick(event) {
  if (dragMoved) {
    event.preventDefault();
    event.stopPropagation();
    dragMoved = false;
    return;
  }

  await openDashboard();
}

function clampPosition(x, y, button) {
  const buttonWidth = button.offsetWidth || 72;
  const buttonHeight = button.offsetHeight || 72;

  return {
    x: Math.max(4, Math.min(window.innerWidth - buttonWidth - 4, x)),
    y: Math.max(4, Math.min(window.innerHeight - buttonHeight - 4, y))
  };
}

function setButtonPosition(button, x, y) {
  const safePosition = clampPosition(x, y, button);

  button.style.left = `${safePosition.x}px`;
  button.style.top = `${safePosition.y}px`;
  button.style.right = "auto";
  button.style.bottom = "auto";

  return safePosition;
}

function startDrag(event) {
  if (!dragEnabled) return;
  if (event.button !== 0) return;

  const button = document.getElementById(DMS_BUTTON_ID);
  if (!button) return;

  const rect = button.getBoundingClientRect();

  isDragging = true;
  dragMoved = false;
  dragOffsetX = event.clientX - rect.left;
  dragOffsetY = event.clientY - rect.top;

  button.classList.add("dms-dragging");

  document.addEventListener("mousemove", onDrag);
  document.addEventListener("mouseup", stopDrag);

  event.preventDefault();
}

function onDrag(event) {
  if (!isDragging) return;

  const button = document.getElementById(DMS_BUTTON_ID);
  if (!button) return;

  dragMoved = true;

  setButtonPosition(button, event.clientX - dragOffsetX, event.clientY - dragOffsetY);
}

function stopDrag() {
  if (!isDragging) return;

  const button = document.getElementById(DMS_BUTTON_ID);
  if (!button) return;

  const rect = button.getBoundingClientRect();
  const safePosition = setButtonPosition(button, rect.left, rect.top);

  chrome.storage.local.set({
    [DMS_STORAGE_POSITION_KEY]: safePosition
  });

  isDragging = false;
  button.classList.remove("dms-dragging");

  document.removeEventListener("mousemove", onDrag);
  document.removeEventListener("mouseup", stopDrag);
}

function applySavedPosition(button) {
  chrome.storage.local.get(DMS_STORAGE_POSITION_KEY, (result) => {
    const position = result[DMS_STORAGE_POSITION_KEY];

    if (!position) {
      const defaultPosition = getDefaultButtonPosition();
      setButtonPosition(button, defaultPosition.x, defaultPosition.y);
      return;
    }

    setButtonPosition(button, position.x, position.y);
  });
}

function applyDragState() {
  chrome.storage.local.get(DMS_STORAGE_DRAG_KEY, (result) => {
    dragEnabled = result[DMS_STORAGE_DRAG_KEY] !== false;

    const button = document.getElementById(DMS_BUTTON_ID);
    if (!button) return;

    button.classList.toggle("dms-drag-disabled", !dragEnabled);
  });
}

function resetButtonPosition() {
  const button = document.getElementById(DMS_BUTTON_ID);
  if (!button) return;

  const defaultPosition = getDefaultButtonPosition();
  const safePosition = setButtonPosition(button, defaultPosition.x, defaultPosition.y);

  chrome.storage.local.set({
    [DMS_STORAGE_POSITION_KEY]: safePosition
  });
}

async function renderButton() {
  if (!(await canUseModsupport())) {
    removeButton();
    return;
  }

  if (document.getElementById(DMS_BUTTON_ID)) {
    applyDragState();
    return;
  }

  const button = createButton();
  document.body.appendChild(button);
  applySavedPosition(button);
  applyDragState();
}

function buildMessageId(source, node, username, message, timestampText) {
  const domId =
    node.getAttribute("msg-id") ||
    node.querySelector("[msg-id]")?.getAttribute("msg-id") ||
    node.getAttribute("data-id") ||
    node.getAttribute("id");

  if (domId) return `${source}:${domId}`;

  return `${source}:${username}:${timestampText}:${message}`.slice(0, 300);
}

function sendChatMessage(parsedMessage) {
  if (!parsedMessage || !parsedMessage.message || !parsedMessage.username) return;

  if (DMS_CHAT_STATE.observedIds.has(parsedMessage.id)) return;
  DMS_CHAT_STATE.observedIds.add(parsedMessage.id);

  chrome.storage.local.get("dmsContentMode", (result) => {
    const contentMode = result.dmsContentMode || "safe";

    const analysis = window.DrumgodMessageAnalyzer
      ? window.DrumgodMessageAnalyzer.analyze(parsedMessage, { contentMode })
      : {
          score: 0,
          level: "normal",
          flags: [],
          contentMode,
          reviewed: false,
          autoAction: false
        };

    chrome.runtime.sendMessage({
      type: "CHAT_MESSAGE",
      payload: {
        ...parsedMessage,
        analysis
      }
    });
  });
}

const CHAT_ADAPTERS = [
  {
    name: "7tv",
    containerSelectors: [
      "#seventv-message-container",
      "main.seventv-chat-list",
      ".seventv-chat-list",
      "section[aria-label='Chat']"
    ],
    messageSelector: ".seventv-message",
    parseMessage(node) {
      const userElement = node.querySelector(".seventv-chat-user-username");
      const bodyElement = node.querySelector(".seventv-chat-message-body");
      const timestampElement = node.querySelector(".seventv-chat-message-timestamp");

      const username = cleanText(userElement?.innerText);
      const message = cleanText(bodyElement?.innerText);
      const timestampText = cleanText(timestampElement?.innerText);

      if (!username || !message) return null;

      return {
        id: buildMessageId("7tv", node, username, message, timestampText),
        source: "7tv",
        channel: getCurrentTwitchChannel(),
        username,
        message,
        timestamp: new Date().toISOString(),
        displayedTime: timestampText,
        rawText: cleanText(node.innerText)
      };
    }
  },

  {
    name: "twitch",
    containerSelectors: [
      "[data-test-selector='chat-scrollable-area__message-container']",
      ".chat-scrollable-area__message-container",
      "[aria-label='Chat messages']",
      "section[aria-label='Chat']"
    ],
    messageSelector: "[data-a-target='chat-line-message']",
    parseMessage(node) {
      const userElement =
        node.querySelector("[data-a-target='chat-message-username']") ||
        node.querySelector(".chat-author__display-name");

      const fragments = node.querySelectorAll(".text-fragment");
      const bodyElement = node.querySelector("[data-a-target='chat-message-text']");

      const username = cleanText(userElement?.innerText);

      const message =
        fragments.length > 0
          ? cleanText(Array.from(fragments).map((fragment) => fragment.innerText).join(""))
          : cleanText(bodyElement?.innerText);

      if (!username || !message) return null;

      return {
        id: buildMessageId("twitch", node, username, message, ""),
        source: "twitch",
        channel: getCurrentTwitchChannel(),
        username,
        message,
        timestamp: new Date().toISOString(),
        displayedTime: "",
        rawText: cleanText(node.innerText)
      };
    }
  },

  {
    name: "bttv-ffz",
    containerSelectors: [
      ".chat-list__lines",
      ".chat-scrollable-area__message-container",
      "[aria-label='Chat messages']",
      "section[aria-label='Chat']"
    ],
    messageSelector: ".chat-line__message, .chat-line__message-container, .ffz--chat-line, .bttv-chat-message",
    parseMessage(node) {
      const userElement =
        node.querySelector(".chat-author__display-name") ||
        node.querySelector("[data-a-target='chat-message-username']") ||
        node.querySelector(".username") ||
        node.querySelector(".ffz-chat-line__username");

      const bodyElement =
        node.querySelector("[data-a-target='chat-message-text']") ||
        node.querySelector(".message") ||
        node.querySelector(".chat-line__message-body");

      const fragments = node.querySelectorAll(".text-fragment");
      const username = cleanText(userElement?.innerText);

      const message =
        fragments.length > 0
          ? cleanText(Array.from(fragments).map((fragment) => fragment.innerText).join(""))
          : cleanText(bodyElement?.innerText || node.innerText?.replace(username, ""));

      if (!username || !message) return null;

      return {
        id: buildMessageId("bttv-ffz", node, username, message, ""),
        source: "bttv-ffz",
        channel: getCurrentTwitchChannel(),
        username,
        message,
        timestamp: new Date().toISOString(),
        displayedTime: "",
        rawText: cleanText(node.innerText)
      };
    }
  }
];

function findAdapter() {
  for (const adapter of CHAT_ADAPTERS) {
    for (const selector of adapter.containerSelectors) {
      const container = document.querySelector(selector);
      if (!container) continue;

      const messages = container.querySelectorAll(adapter.messageSelector);

      if (messages.length > 0) {
        return { adapter, container };
      }
    }
  }

  return null;
}

function handleMessageNode(adapter, node) {
  if (!(node instanceof HTMLElement)) return;
  if (DMS_CHAT_STATE.observedNodes.has(node)) return;

  const parsed = adapter.parseMessage(node);
  if (!parsed) return;

  DMS_CHAT_STATE.observedNodes.add(node);
  sendChatMessage(parsed);
}

function scanExistingMessages(adapter, container) {
  const messages = container.querySelectorAll(adapter.messageSelector);

  messages.forEach((node) => {
    handleMessageNode(adapter, node);
  });
}

async function startChatObserver() {
  if (!(await canUseModsupport())) return;

  const result = findAdapter();

  if (!result) {
    setTimeout(startChatObserver, 1500);
    return;
  }

  const { adapter, container } = result;

  if (DMS_CHAT_STATE.activeAdapter === adapter.name && DMS_CHAT_STATE.observer) {
    return;
  }

  if (DMS_CHAT_STATE.observer) {
    DMS_CHAT_STATE.observer.disconnect();
  }

  DMS_CHAT_STATE.activeAdapter = adapter.name;

  scanExistingMessages(adapter, container);

  DMS_CHAT_STATE.observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (!(node instanceof HTMLElement)) continue;

        if (node.matches?.(adapter.messageSelector)) {
          handleMessageNode(adapter, node);
        }

        const nestedMessages = node.querySelectorAll?.(adapter.messageSelector);

        nestedMessages?.forEach((nestedNode) => {
          handleMessageNode(adapter, nestedNode);
        });
      }
    }
  });

  DMS_CHAT_STATE.observer.observe(container, {
    childList: true,
    subtree: true
  });
}

function stopChatObserver() {
  if (DMS_CHAT_STATE.observer) {
    DMS_CHAT_STATE.observer.disconnect();
    DMS_CHAT_STATE.observer = null;
    DMS_CHAT_STATE.activeAdapter = null;
  }
}

window.addEventListener("resize", () => {
  const button = document.getElementById(DMS_BUTTON_ID);
  if (!button) return;

  const rect = button.getBoundingClientRect();
  const safePosition = setButtonPosition(button, rect.left, rect.top);

  chrome.storage.local.set({
    [DMS_STORAGE_POSITION_KEY]: safePosition
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message?.type) return;

  if (message.type === "DMS_SET_DRAG_ENABLED") {
    dragEnabled = Boolean(message.payload.enabled);

    chrome.storage.local.set({
      [DMS_STORAGE_DRAG_KEY]: dragEnabled
    });

    applyDragState();
  }

  if (message.type === "DMS_RESET_BUTTON_POSITION") {
    resetButtonPosition();
  }
});

async function boot() {
  await renderButton();
  await sendActiveChannelToBackground();

  if (await canUseModsupport()) {
    await sendStreamInfoToBackground();
    await sendAdInfoToBackground();
    await startChatObserver();
  }

  setInterval(async () => {
    if (location.href !== DMS_CHAT_STATE.lastUrl) {
      DMS_CHAT_STATE.lastUrl = location.href;
      DMS_CHAT_STATE.observedIds.clear();
      stopChatObserver();
    }

    if (await canUseModsupport()) {
      await renderButton();
      await sendActiveChannelToBackground();
      await sendStreamInfoToBackground();
      await sendAdInfoToBackground();
      await startChatObserver();
    } else {
      removeButton();
      stopChatObserver();
      await sendActiveChannelToBackground();
    }
  }, 1500);
}

boot();