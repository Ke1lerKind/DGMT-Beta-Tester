window.DrumgodMessageAnalyzer = {
  modes: {
    SAFE: "safe",
    MATURE: "mature"
  },

  severeTerms: [
    "kill yourself",
    "kys",
    "hang yourself",
    "bring dich um",
    "geh sterben",
    "verreck",
    "stirb",
    "rape",
    "vergewaltigung"
  ],

  extremistTerms: [
    "heil hitler",
    "sieg heil",
    "hitlergruß",
    "hitlergruss",
    "hakenkreuz",
    "ss rune",
    "nazi propaganda",
    "nsdap",
    "white power",
    "1488",
    "88",
    "14 words"
  ],

  harassmentTerms: [
    "hurensohn",
    "hurentochter",
    "huso",
    "wichser",
    "pisser",
    "spast",
    "spasti",
    "bastard",
    "opfer",
    "idiot",
    "trottel",
    "vollidiot",
    "missgeburt",
    "abschaum",
    "versager",
    "drecksau",
    "arschloch",
    "fotze",
    "nutte",

    "moron",
    "trash",
    "loser",
    "worthless",
    "retard",
    "scumbag",
    "dumbass",
    "asshole",

    "pendejo",
    "gilipollas",
    "puto",
    "puta",
    "cabrón",
    "cabron",

    "babaca",
    "otario",

    "stronzo",
    "coglione",

    "connard",
    "conasse",
    "salope",

    "salak",
    "aptal",
    "orospu",
    "piç",
    "pic",

    "debil",
    "kurwa",
    "klootzak",
    "sukkel",
    "blyat",
    "suka"
  ],

  matureLanguageTerms: [
    "fuck",
    "shit",
    "damn",
    "bitch",
    "wtf",
    "scheiße",
    "scheisse",
    "ficken",
    "gefickt",
    "arsch",
    "kacke",
    "mist",
    "mierda",
    "merda",
    "merde",
    "kurwa",
    "blyat"
  ],

  protectedClassHints: [
    "jude",
    "jew",
    "muslim",
    "christ",
    "black",
    "white",
    "asian",
    "schwul",
    "gay",
    "trans",
    "lesbian",
    "behindert",
    "disabled"
  ],

  linkPatterns: [
    /https?:\/\//i,
    /www\./i,
    /discord\.gg/i,
    /\.com\b/i,
    /\.net\b/i,
    /\.gg\b/i,
    /\.tv\b/i
  ],

  normalize(text) {
    return String(text || "")
      .toLowerCase()
      .replace(/[!?.,"'`´:;()[\]{}<>|/\\_-]/g, " ")
      .replace(/[@#$%^&*+=~]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  },

  escapeRegex(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  },

  containsAny(text, list) {
    const normalized = this.normalize(text);

    return list.some((term) => {
      const normalizedTerm = this.normalize(term);
      const pattern = new RegExp(`(^|\\s)${this.escapeRegex(normalizedTerm)}($|\\s)`, "i");
      return pattern.test(normalized);
    });
  },

  hasLink(text) {
    return this.linkPatterns.some((pattern) => pattern.test(text));
  },

  getCapsRatio(text) {
    const letters = String(text || "").replace(/[^a-zA-ZÄÖÜäöüß]/g, "");
    if (letters.length < 8) return 0;

    const caps = letters.replace(/[^A-ZÄÖÜ]/g, "");
    return caps.length / letters.length;
  },

  hasRepeatedChars(text) {
    return /(.)\1{5,}/i.test(text);
  },

  getRepeatedWordScore(text) {
    const words = this.normalize(text).split(" ").filter(Boolean);
    if (words.length < 4) return 0;

    const counts = {};

    for (const word of words) {
      counts[word] = (counts[word] || 0) + 1;
    }

    const maxCount = Math.max(...Object.values(counts));

    if (maxCount >= 5) return 45;
    if (maxCount >= 4) return 35;
    if (maxCount >= 3) return 20;

    return 0;
  },

  isLikelyQuoteOrDiscussion(text) {
    const normalized = this.normalize(text);

    const hints = [
      "zitat",
      "quote",
      "hat gesagt",
      "sagte",
      "he said",
      "she said",
      "someone said",
      "das wort",
      "word means",
      "bedeutet",
      "nicht sagen",
      "sag nicht",
      "dont say",
      "don't say",
      "historisch",
      "geschichte",
      "history",
      "documentary",
      "dokumentation"
    ];

    return hints.some((hint) => normalized.includes(hint));
  },

  isDirectAttack(text) {
    const normalized = this.normalize(text);

    const directHints = [
      "du bist",
      "du kleiner",
      "du drecks",
      "du hurensohn",
      "du idiot",
      "deine mutter",
      "you are",
      "you're",
      "u are",
      "your mom",
      "@"
    ];

    return directHints.some((hint) => normalized.includes(hint));
  },

  isNegatedWarning(text) {
    const normalized = this.normalize(text);

    const hints = [
      "nicht",
      "kein",
      "keine",
      "dont",
      "don't",
      "do not",
      "stop saying",
      "hör auf",
      "sag nicht",
      "nicht beleidigen"
    ];

    return hints.some((hint) => normalized.includes(hint));
  },

  getContextMultiplier(text) {
    let multiplier = 1;

    if (this.isLikelyQuoteOrDiscussion(text)) {
      multiplier -= 0.45;
    }

    if (this.isNegatedWarning(text)) {
      multiplier -= 0.25;
    }

    if (this.isDirectAttack(text)) {
      multiplier += 0.45;
    }

    return Math.max(0.25, Math.min(1.6, multiplier));
  },

  analyze(chatMessage, context = {}) {
    const text = String(chatMessage?.message || "");
    const normalized = this.normalize(text);
    const mode = context.contentMode || this.modes.SAFE;

    let score = 0;
    const flags = [];

    const capsRatio = this.getCapsRatio(text);

    if (capsRatio > 0.75 && text.length >= 12) {
      score += mode === this.modes.MATURE ? 10 : 25;
      flags.push("caps");
    }

    if (this.hasRepeatedChars(text)) {
      score += 20;
      flags.push("repeated-chars");
    }

    const repeatedWordScore = this.getRepeatedWordScore(text);
    if (repeatedWordScore > 0) {
      score += repeatedWordScore;
      flags.push("repeated-words");
    }

    if (this.hasLink(text)) {
      score += 25;
      flags.push("link");
    }

    if (this.containsAny(normalized, this.severeTerms)) {
      score += 85;
      flags.push("severe");
    }

    if (this.containsAny(normalized, this.extremistTerms)) {
      score += 90;
      flags.push("extremism");
    }

    if (this.containsAny(normalized, this.harassmentTerms)) {
      score += this.isDirectAttack(text)
        ? mode === this.modes.MATURE ? 65 : 75
        : mode === this.modes.MATURE ? 35 : 50;

      flags.push("harassment");
    }

    if (this.containsAny(normalized, this.protectedClassHints)) {
      score += 20;
      flags.push("protected-class-context");
    }

    if (this.containsAny(normalized, this.matureLanguageTerms)) {
      if (mode === this.modes.SAFE) {
        score += 20;
        flags.push("mature-language");
      }

      if (mode === this.modes.MATURE && this.isDirectAttack(text)) {
        score += 20;
        flags.push("directed-mature-language");
      }
    }

    const contextMultiplier = this.getContextMultiplier(text);
    score = Math.round(score * contextMultiplier);
    score = Math.min(100, Math.max(0, score));

    let level = "normal";

    if (score >= 70) {
      level = "danger";
    } else if (score >= 40) {
      level = "warning";
    } else if (score >= 20) {
      level = "notice";
    }

    return {
      score,
      level,
      flags,
      contextMultiplier,
      contentMode: mode,
      reviewed: false,
      autoAction: false
    };
  }
};