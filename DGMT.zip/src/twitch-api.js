window.DrumgodTwitchApi = {
  async getStreamInfo(channel) {
    return null;
  },

  async updateStreamInfo(channel, data) {
    return {
      ok: false,
      reason: "Twitch API is not configured yet.",
      channel,
      data
    };
  },

  async getAdInfo(channel) {
    return null;
  },

  async timeoutUser(channel, username, seconds, reason = "") {
    return {
      ok: false,
      reason: "Twitch API is not configured yet.",
      channel,
      username,
      seconds,
      reasonText: reason
    };
  },

  async banUser(channel, username, reason = "") {
    return {
      ok: false,
      reason: "Twitch API is not configured yet.",
      channel,
      username,
      reasonText: reason
    };
  },

  async deleteMessage(channel, messageId) {
    return {
      ok: false,
      reason: "Twitch API is not configured yet.",
      channel,
      messageId
    };
  }
};