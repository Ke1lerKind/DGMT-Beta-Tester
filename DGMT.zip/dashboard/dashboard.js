console.log("[Drumgod Modsupport] Dashboard loaded.");

const STORAGE_LANGUAGE_KEY = "dmsLanguage";
const STORAGE_DRAG_KEY = "dmsButtonDraggable";
const STORAGE_CONTENT_MODE_KEY = "dmsContentMode";
const STORAGE_USER_NOTES_KEY = "dmsUserNotes";
const STORAGE_ACTION_LOG_KEY = "dmsActionLog";
const STORAGE_COLLAPSE_KEY = "dmsCollapsedPanels";

const urlParams = new URLSearchParams(window.location.search);
const TARGET_TAB_ID = Number(urlParams.get("tabId"));

const translations = {
  en: {
    subtitle: "Chat chaos, but make it draggable.",
    dashboardTab: "Dashboard",
    streamTab: "Stream Info",
    settingsTab: "Settings",
    settingsTitle: "Settings",

    languageLabel: "Language",
    languageDescription: "Choose the dashboard language.",
    contentModeTitle: "Content Mode",
    contentModeDescription: "Choose how strict the message analysis should be.",
    safeMode: "18- / Family Safe",
    matureMode: "18+ / Mature Stream",
    dragLabel: "Logo dragging",
    dragDescription: "Allow the floating logo to be moved.",
    dragCheckbox: "Enable dragging",
    resetPosition: "Reset position",

    activeChatTitle: "Active Chat",
    statusTitle: "Status",
    liveChatTitle: "Live Chat Data",
    noMessages: "No chat data detected yet.",
    noFilteredMessages: "No flagged messages yet.",
    filteredChatTitle: "Filtered Chat",

    selectedMessageTitle: "Selected Message",
    selectedMessageEmpty: "Select a chat message to moderate that exact message.",
    selectedMessageShort: "Selected Message",
    messageLabel: "Message",
    copySelectedMessage: "Copy selected message",

    userAnalysisTitle: "User Analysis",
    userAnalysisDescription: "Select a user to view local stats.",
    userAnalysisMuted: "Recent messages, flags, history and statistics.",
    selectedUserLabel: "Selected User",
    clearSelection: "Clear",
    userMessages: "Messages",
    userFlagged: "Flagged",
    userHighestScore: "Highest Score",
    userAverageScore: "Average Score",
    userFlagsTitle: "Detected Flags",
    userNotesTitle: "Local Moderator Note",
    userRecentMessagesTitle: "Recent Messages",
    noFlags: "No flags",
    saveNote: "Save note",

    actionsTitle: "Moderation Actions",
    selectMessageForActions: "Select a message to prepare moderation actions.",
    timeoutBuilderTitle: "Timeout Builder",
    commandPreview: "Command Preview",
    copyTimeoutCommand: "Copy timeout command",
    sendTimeout: "Send timeout",
    reasonLabel: "Reason / note",
    actionLogTitle: "Action Log",
    clearLog: "Clear log",
    noActionsYet: "No actions prepared yet.",

    apiWipBadge: "WIP · API required",
    apiWipNote: "WIP · Twitch API required for direct actions.",
    sendTimeoutWipNote: "WIP · Direct timeout requires Twitch API. For now this prepares/copies the command.",

    automodTitle: "AutoMod",
    automodApprove: "Approve",
    automodDeny: "Deny",
    shoutoutTitle: "Shoutout",
    copyShoutout: "Copy shoutout",
    shoutoutSelectedUser: "Shoutout selected user",

    years: "Years",
    months: "Months",
    days: "Days",
    hours: "Hours",
    minutes: "Minutes",
    seconds: "Seconds",

    ban: "Ban",
    timeout: "Timeout",
    deleteSelectedMessage: "Delete message",
    report: "Report",
    pinSelectedMessage: "Pin message",
    ignore: "Ignore",

    noActiveChat: "No Twitch chat detected.",
    activeIn: "Active in:",
    statusReady: "Ready. Waiting for chat data.",
    statusLoaded: "Existing chat data loaded.",
    statusLive: "Live connected. Receiving chat data.",
    statusWaiting: "Dashboard loaded. Waiting for chat data.",
    statusCommandCopied: "Command copied to clipboard.",
    statusMessageCopied: "Selected message copied.",
    statusActionPrepared: "Action prepared.",
    statusUserIgnored: "User ignored locally.",

    streamInfoTitle: "Stream Info",
    modStatusTitle: "Moderator Status",
    streamTitleLabel: "Title",
    streamGameLabel: "Game / Category",
    streamLiveLabel: "Live Status",
    adStatusLabel: "Ad Status",
    streamOnline: "Live",
    streamOffline: "Offline",
    modDetected: "Moderator rights detected.",
    modNotDetected: "Moderator rights not detected.",
    adRunning: "Ad running",
    noAd: "No ad signal detected",
    streamEditNote: "Editing will come later with Twitch API connection.",
    saveStreamInfo: "Save changes"
  },

  de: {
    subtitle: "Chat-Chaos, aber wenigstens verschiebbar.",
    dashboardTab: "Dashboard",
    streamTab: "Streaminfos",
    settingsTab: "Einstellungen",
    settingsTitle: "Einstellungen",

    languageLabel: "Sprache",
    languageDescription: "Wähle die Sprache des Dashboards.",
    contentModeTitle: "Content-Modus",
    contentModeDescription: "Wähle, wie streng Nachrichten bewertet werden.",
    safeMode: "18- / Family Safe",
    matureMode: "18+ / Mature Stream",
    dragLabel: "Logo verschieben",
    dragDescription: "Erlaubt das Verschieben des schwebenden Logos.",
    dragCheckbox: "Verschieben aktivieren",
    resetPosition: "Position zurücksetzen",

    activeChatTitle: "Aktiver Chat",
    statusTitle: "Status",
    liveChatTitle: "Live Chatdaten",
    noMessages: "Noch keine Chatdaten erkannt.",
    noFilteredMessages: "Noch keine markierten Nachrichten.",
    filteredChatTitle: "Gefilterter Chat",

    selectedMessageTitle: "Ausgewählte Nachricht",
    selectedMessageEmpty: "Wähle eine Chatnachricht aus, um genau diese Nachricht zu moderieren.",
    selectedMessageShort: "Ausgewählte Nachricht",
    messageLabel: "Nachricht",
    copySelectedMessage: "Ausgewählte Nachricht kopieren",

    userAnalysisTitle: "User Analyse",
    userAnalysisDescription: "Wähle einen User aus, um lokale Statistiken zu sehen.",
    userAnalysisMuted: "Letzte Nachrichten, Auffälligkeiten, Historie und Statistiken.",
    selectedUserLabel: "Ausgewählter User",
    clearSelection: "Leeren",
    userMessages: "Nachrichten",
    userFlagged: "Markiert",
    userHighestScore: "Höchster Score",
    userAverageScore: "Ø Score",
    userFlagsTitle: "Erkannte Flags",
    userNotesTitle: "Lokale Mod-Notiz",
    userRecentMessagesTitle: "Letzte Nachrichten",
    noFlags: "Keine Flags",
    saveNote: "Notiz speichern",

    actionsTitle: "Moderationsaktionen",
    selectMessageForActions: "Wähle eine Nachricht aus, um Moderationsaktionen vorzubereiten.",
    timeoutBuilderTitle: "Timeout Builder",
    commandPreview: "Command-Vorschau",
    copyTimeoutCommand: "Timeout-Befehl kopieren",
    sendTimeout: "Timeout abschicken",
    reasonLabel: "Grund / Notiz",
    actionLogTitle: "Action Log",
    clearLog: "Log leeren",
    noActionsYet: "Noch keine Aktionen vorbereitet.",

    apiWipBadge: "WIP · API benötigt",
    apiWipNote: "WIP · Twitch API für direkte Aktionen benötigt.",
    sendTimeoutWipNote: "WIP · Direkter Timeout benötigt die Twitch API. Aktuell wird der Befehl vorbereitet/kopiert.",

    automodTitle: "AutoMod",
    automodApprove: "Freigeben",
    automodDeny: "Ablehnen",
    shoutoutTitle: "Shoutout",
    copyShoutout: "Shoutout kopieren",
    shoutoutSelectedUser: "Ausgewählten User shoutouten",

    years: "Jahre",
    months: "Monate",
    days: "Tage",
    hours: "Stunden",
    minutes: "Minuten",
    seconds: "Sekunden",

    ban: "Ban",
    timeout: "Timeout",
    deleteSelectedMessage: "Nachricht löschen",
    report: "Melden",
    pinSelectedMessage: "Nachricht pinnen",
    ignore: "Ignorieren",

    noActiveChat: "Kein Twitch-Chat erkannt.",
    activeIn: "Aktiv in:",
    statusReady: "Bereit. Warte auf Chatdaten.",
    statusLoaded: "Bestehende Chatdaten geladen.",
    statusLive: "Live verbunden. Chatdaten werden empfangen.",
    statusWaiting: "Dashboard geladen. Warte auf Chatdaten.",
    statusCommandCopied: "Command in Zwischenablage kopiert.",
    statusMessageCopied: "Ausgewählte Nachricht kopiert.",
    statusActionPrepared: "Aktion vorbereitet.",
    statusUserIgnored: "User lokal ignoriert.",

    streamInfoTitle: "Streaminfos",
    modStatusTitle: "Moderator-Status",
    streamTitleLabel: "Titel",
    streamGameLabel: "Spiel / Kategorie",
    streamLiveLabel: "Live-Status",
    adStatusLabel: "Werbung",
    streamOnline: "Live",
    streamOffline: "Offline",
    modDetected: "Moderator-Rechte erkannt.",
    modNotDetected: "Moderator-Rechte nicht erkannt.",
    adRunning: "Werbung läuft",
    noAd: "Kein Werbesignal erkannt",
    streamEditNote: "Bearbeiten kommt später mit Twitch-API-Verbindung.",
    saveStreamInfo: "Änderungen speichern"
  }
};

const statusElement = document.getElementById("dashboard-status");
const activeChatElement = document.getElementById("active-chat");
const chatFeedElement = document.getElementById("chat-feed");
const filteredFeedElement = document.getElementById("filtered-feed");
const messageCountElement = document.getElementById("message-count");

const selectedMessageEmpty = document.getElementById("selected-message-empty");
const selectedMessageContent = document.getElementById("selected-message-content");
const selectedMessageUser = document.getElementById("selected-message-user");
const selectedMessageText = document.getElementById("selected-message-text");
const clearSelectedMessageButton = document.getElementById("clear-selected-message");
const copySelectedMessageButton = document.getElementById("copy-selected-message");

const languageSelect = document.getElementById("language-select");
const contentModeSelect = document.getElementById("content-mode-select");
const dragCheckbox = document.getElementById("drag-checkbox");
const resetPositionButton = document.getElementById("reset-position-button");

const streamModInput = document.getElementById("stream-mod-input");
const streamTitleInput = document.getElementById("stream-title-input");
const streamGameInput = document.getElementById("stream-game-input");
const streamLiveInput = document.getElementById("stream-live-input");
const streamAdInput = document.getElementById("stream-ad-input");

const userAnalysisEmpty = document.getElementById("user-analysis-empty");
const userAnalysisContent = document.getElementById("user-analysis-content");
const selectedUsernameElement = document.getElementById("selected-username");
const clearSelectedUserButton = document.getElementById("clear-selected-user");
const userMessageCountElement = document.getElementById("user-message-count");
const userFlaggedCountElement = document.getElementById("user-flagged-count");
const userHighestScoreElement = document.getElementById("user-highest-score");
const userAverageScoreElement = document.getElementById("user-average-score");
const userFlagsElement = document.getElementById("user-flags");
const userNoteInput = document.getElementById("user-note-input");
const saveUserNoteButton = document.getElementById("save-user-note");
const userRecentMessagesElement = document.getElementById("user-recent-messages");

const actionEmpty = document.getElementById("action-empty");
const actionContent = document.getElementById("action-content");
const actionSelectedUsernameElement = document.getElementById("action-selected-username");
const actionSelectedMessageState = document.getElementById("action-selected-message-state");
const actionReasonInput = document.getElementById("action-reason");
const actionLogElement = document.getElementById("action-log");
const clearActionLogButton = document.getElementById("clear-action-log");
const copyTimeoutCommandButton = document.getElementById("copy-timeout-command");
const sendTimeoutActionButton = document.getElementById("send-timeout-action");
const commandPreviewOutput = document.getElementById("command-preview-output");

const shoutoutUsernameInput = document.getElementById("shoutout-username");
const copyShoutoutCommandButton = document.getElementById("copy-shoutout-command");
const useSelectedUserShoutoutButton = document.getElementById("use-selected-user-shoutout");

const timeoutInputs = {
  years: document.getElementById("timeout-years"),
  months: document.getElementById("timeout-months"),
  days: document.getElementById("timeout-days"),
  hours: document.getElementById("timeout-hours"),
  minutes: document.getElementById("timeout-minutes"),
  seconds: document.getElementById("timeout-seconds")
};

const tabButtons = document.querySelectorAll(".tab-button");
const tabContents = document.querySelectorAll(".tab-content");

const dashboardState = {
  messages: [],
  maxMessages: 200,
  language: "en",
  statusKey: "statusReady",
  activeChannelData: null,
  streamInfo: null,
  adInfo: null,
  selectedUser: null,
  selectedMessageId: null,
  userNotes: {},
  actionLog: []
};

function t(key) {
  return translations[dashboardState.language]?.[key] || translations.en[key] || key;
}

function getSelectedMessage() {
  return dashboardState.messages.find((message) => message.id === dashboardState.selectedMessageId) || null;
}

function getUserKey(username) {
  const channel = dashboardState.activeChannelData?.activeChannel || "unknown";
  return `${channel}:${String(username || "").toLowerCase()}`;
}

function setStatusKey(key) {
  dashboardState.statusKey = key || "statusReady";
  updateStatus(t(dashboardState.statusKey));
}

function applyLanguage(language) {
  dashboardState.language = language;
  document.documentElement.lang = language;

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.getAttribute("data-i18n");
    element.textContent = t(key);
  });

  if (languageSelect) languageSelect.value = language;

  updateActiveChat(dashboardState.activeChannelData);
  updateStreamInfo(dashboardState.streamInfo);
  updateAdInfo(dashboardState.adInfo);
  renderMessages();
  renderSelectedMessagePanel();
  renderUserAnalysis();
  renderActionPanel();
  renderActionLog();
  updateCommandPreview();
  updateStatus(t(dashboardState.statusKey || "statusReady"));
}

function loadLanguage() {
  chrome.storage.local.get(STORAGE_LANGUAGE_KEY, (result) => {
    applyLanguage(result[STORAGE_LANGUAGE_KEY] || "en");
  });
}

function saveLanguage(language) {
  chrome.storage.local.set({ [STORAGE_LANGUAGE_KEY]: language });
  applyLanguage(language);
}

function loadContentMode() {
  chrome.storage.local.get(STORAGE_CONTENT_MODE_KEY, (result) => {
    if (contentModeSelect) contentModeSelect.value = result[STORAGE_CONTENT_MODE_KEY] || "safe";
  });
}

function saveContentMode(mode) {
  chrome.storage.local.set({ [STORAGE_CONTENT_MODE_KEY]: mode });
}

function loadDragSetting() {
  chrome.storage.local.get(STORAGE_DRAG_KEY, (result) => {
    if (dragCheckbox) dragCheckbox.checked = result[STORAGE_DRAG_KEY] !== false;
  });
}

function saveDragSetting(enabled) {
  chrome.storage.local.set({ [STORAGE_DRAG_KEY]: enabled });
  sendToTargetTab({ type: "DMS_SET_DRAG_ENABLED", payload: { enabled } });
}

function loadUserNotes() {
  chrome.storage.local.get(STORAGE_USER_NOTES_KEY, (result) => {
    dashboardState.userNotes = result[STORAGE_USER_NOTES_KEY] || {};
    renderUserAnalysis();
  });
}

function saveUserNote() {
  if (!dashboardState.selectedUser) return;

  const key = getUserKey(dashboardState.selectedUser);
  dashboardState.userNotes[key] = userNoteInput.value || "";

  chrome.storage.local.set({ [STORAGE_USER_NOTES_KEY]: dashboardState.userNotes });
}

function loadActionLog() {
  chrome.storage.local.get(STORAGE_ACTION_LOG_KEY, (result) => {
    dashboardState.actionLog = result[STORAGE_ACTION_LOG_KEY] || [];
    renderActionLog();
  });
}

function saveActionLog() {
  chrome.storage.local.set({ [STORAGE_ACTION_LOG_KEY]: dashboardState.actionLog });
}

function sendToTargetTab(message) {
  if (!Number.isFinite(TARGET_TAB_ID)) return;
  chrome.tabs.sendMessage(TARGET_TAB_ID, message);
}

function resetLogoPosition() {
  sendToTargetTab({ type: "DMS_RESET_BUTTON_POSITION" });
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatTime(message) {
  if (message.displayedTime) return message.displayedTime;

  try {
    return new Date(message.timestamp).toLocaleTimeString(
      dashboardState.language === "de" ? "de-DE" : "en-US",
      { hour: "2-digit", minute: "2-digit", second: "2-digit" }
    );
  } catch {
    return "";
  }
}

function updateStatus(text) {
  if (statusElement) statusElement.textContent = text;
}

function updateActiveChat(data) {
  dashboardState.activeChannelData = data;

  if (activeChatElement) {
    activeChatElement.textContent = data?.activeChannel
      ? `${t("activeIn")} twitch.tv/${data.activeChannel}`
      : t("noActiveChat");
  }

  if (streamModInput) {
    streamModInput.value = data?.isModerator ? t("modDetected") : t("modNotDetected");
  }
}

function updateStreamInfo(streamInfo) {
  dashboardState.streamInfo = streamInfo;

  if (streamTitleInput) streamTitleInput.value = streamInfo?.title || "";
  if (streamGameInput) streamGameInput.value = streamInfo?.game || "";
  if (streamLiveInput) streamLiveInput.value = streamInfo?.isLive ? t("streamOnline") : t("streamOffline");
}

function updateAdInfo(adInfo) {
  dashboardState.adInfo = adInfo;

  if (streamAdInput) {
    streamAdInput.value = adInfo?.isAdRunning ? t("adRunning") : t("noAd");
  }
}

function updateMessageCount() {
  if (messageCountElement) messageCountElement.textContent = String(dashboardState.messages.length);
}

function getFilteredMessages() {
  return dashboardState.messages.filter((message) => {
    const level = message.analysis?.level;
    return level && level !== "normal";
  });
}

function getUserMessages(username) {
  const target = String(username || "").toLowerCase();
  return dashboardState.messages.filter((message) => String(message.username || "").toLowerCase() === target);
}

function getUserStats(username) {
  const messages = getUserMessages(username);
  const flaggedMessages = messages.filter((message) => message.analysis?.level && message.analysis.level !== "normal");
  const scores = messages.map((message) => Number(message.analysis?.score || 0));

  const highestScore = scores.length ? Math.max(...scores) : 0;
  const averageScore = scores.length
    ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length)
    : 0;

  const flagCounts = {};

  for (const message of messages) {
    const flags = Array.isArray(message.analysis?.flags) ? message.analysis.flags : [];
    for (const flag of flags) {
      flagCounts[flag] = (flagCounts[flag] || 0) + 1;
    }
  }

  return { messages, flaggedMessages, highestScore, averageScore, flagCounts };
}

function selectMessage(messageId) {
  const message = dashboardState.messages.find((item) => item.id === messageId);
  if (!message) return;

  dashboardState.selectedMessageId = message.id;
  dashboardState.selectedUser = message.username;

  if (shoutoutUsernameInput) {
    shoutoutUsernameInput.value = message.username || "";
  }

  renderMessages();
  renderSelectedMessagePanel();
  renderUserAnalysis();
  renderActionPanel();
  updateCommandPreview();
}

function clearSelectedUser() {
  dashboardState.selectedUser = null;
  dashboardState.selectedMessageId = null;

  renderMessages();
  renderSelectedMessagePanel();
  renderUserAnalysis();
  renderActionPanel();
  updateCommandPreview();
}

function clearSelectedMessage() {
  dashboardState.selectedMessageId = null;

  renderMessages();
  renderSelectedMessagePanel();
  renderActionPanel();
}

function renderMessageCard(message) {
  const analysis = message.analysis || {};
  const level = analysis.level || "normal";
  const flags = Array.isArray(analysis.flags) ? analysis.flags : [];

  const selectedUserClass =
    dashboardState.selectedUser &&
    String(message.username || "").toLowerCase() === String(dashboardState.selectedUser).toLowerCase()
      ? "selected"
      : "";

  const selectedMessageClass = dashboardState.selectedMessageId === message.id ? "message-selected" : "";

  const flagHtml = flags
    .map((flag) => `<span class="analysis-flag">${escapeHtml(flag)}</span>`)
    .join("");

  const analysisHtml =
    level !== "normal"
      ? `<div class="analysis-flags"><span class="analysis-score">Score ${escapeHtml(analysis.score ?? 0)}</span>${flagHtml}</div>`
      : "";

  return `
    <article class="chat-message ${escapeHtml(level)} ${selectedUserClass} ${selectedMessageClass}" data-message-id="${escapeHtml(message.id)}">
      <div class="chat-message-header">
        <span class="chat-username">${escapeHtml(message.username)}</span>
        <span class="chat-time">${escapeHtml(formatTime(message))}</span>
      </div>

      <div class="chat-text">${escapeHtml(message.message)}</div>

      <div class="chat-meta">
        <span class="chat-source">${escapeHtml(message.source || "unknown")}</span>
      </div>

      ${analysisHtml}
    </article>
  `;
}

function bindMessageClicks(rootElement) {
  rootElement.querySelectorAll(".chat-message[data-message-id]").forEach((messageElement) => {
    messageElement.addEventListener("click", () => {
      selectMessage(messageElement.getAttribute("data-message-id"));
    });
  });
}

function renderFilteredMessages() {
  if (!filteredFeedElement) return;

  const filteredMessages = getFilteredMessages();

  if (filteredMessages.length === 0) {
    filteredFeedElement.innerHTML = `<div class="empty-state">${escapeHtml(t("noFilteredMessages"))}</div>`;
    return;
  }

  filteredFeedElement.innerHTML = filteredMessages.map((message) => renderMessageCard(message)).join("");
  bindMessageClicks(filteredFeedElement);
}

function renderMessages() {
  if (!chatFeedElement) return;

  if (dashboardState.messages.length === 0) {
    chatFeedElement.innerHTML = `<div class="empty-state">${escapeHtml(t("noMessages"))}</div>`;
    updateMessageCount();
    renderFilteredMessages();
    return;
  }

  chatFeedElement.innerHTML = dashboardState.messages.map((message) => renderMessageCard(message)).join("");

  bindMessageClicks(chatFeedElement);
  updateMessageCount();
  renderFilteredMessages();
}

function renderSelectedMessagePanel() {
  if (!selectedMessageEmpty || !selectedMessageContent) return;

  const message = getSelectedMessage();

  if (!message) {
    selectedMessageEmpty.classList.remove("hidden");
    selectedMessageContent.classList.add("hidden");
    return;
  }

  selectedMessageEmpty.classList.add("hidden");
  selectedMessageContent.classList.remove("hidden");

  selectedMessageUser.textContent = message.username || "-";
  selectedMessageText.textContent = message.message || "-";
}

function renderUserAnalysis() {
  if (!userAnalysisEmpty || !userAnalysisContent) return;

  const username = dashboardState.selectedUser;

  if (!username) {
    userAnalysisEmpty.classList.remove("hidden");
    userAnalysisContent.classList.add("hidden");
    return;
  }

  const stats = getUserStats(username);
  const userKey = getUserKey(username);

  userAnalysisEmpty.classList.add("hidden");
  userAnalysisContent.classList.remove("hidden");

  selectedUsernameElement.textContent = username;
  userMessageCountElement.textContent = String(stats.messages.length);
  userFlaggedCountElement.textContent = String(stats.flaggedMessages.length);
  userHighestScoreElement.textContent = String(stats.highestScore);
  userAverageScoreElement.textContent = String(stats.averageScore);

  const flagEntries = Object.entries(stats.flagCounts).sort((a, b) => b[1] - a[1]);

  userFlagsElement.innerHTML =
    flagEntries.length === 0
      ? `<span class="analysis-flag">${escapeHtml(t("noFlags"))}</span>`
      : flagEntries
          .map(([flag, count]) => `<span class="analysis-flag">${escapeHtml(flag)} ×${count}</span>`)
          .join("");

  userNoteInput.value = dashboardState.userNotes[userKey] || "";

  const recentMessages = stats.messages.slice(0, 8);

  userRecentMessagesElement.innerHTML =
    recentMessages.length === 0
      ? `<div class="empty-state">${escapeHtml(t("noMessages"))}</div>`
      : recentMessages.map((message) => renderMessageCard(message)).join("");

  bindMessageClicks(userRecentMessagesElement);
}

function getTimeoutSeconds() {
  const years = Number(timeoutInputs.years?.value || 0);
  const months = Number(timeoutInputs.months?.value || 0);
  const days = Number(timeoutInputs.days?.value || 0);
  const hours = Number(timeoutInputs.hours?.value || 0);
  const minutes = Number(timeoutInputs.minutes?.value || 0);
  const seconds = Number(timeoutInputs.seconds?.value || 0);

  return Math.max(
    1,
    Math.floor(
      years * 365 * 24 * 60 * 60 +
        months * 30 * 24 * 60 * 60 +
        days * 24 * 60 * 60 +
        hours * 60 * 60 +
        minutes * 60 +
        seconds
    )
  );
}

function setTimeoutFromSeconds(totalSeconds) {
  let remaining = Number(totalSeconds || 0);

  const years = Math.floor(remaining / (365 * 24 * 60 * 60));
  remaining -= years * 365 * 24 * 60 * 60;

  const months = Math.floor(remaining / (30 * 24 * 60 * 60));
  remaining -= months * 30 * 24 * 60 * 60;

  const days = Math.floor(remaining / (24 * 60 * 60));
  remaining -= days * 24 * 60 * 60;

  const hours = Math.floor(remaining / (60 * 60));
  remaining -= hours * 60 * 60;

  const minutes = Math.floor(remaining / 60);
  remaining -= minutes * 60;

  if (timeoutInputs.years) timeoutInputs.years.value = years;
  if (timeoutInputs.months) timeoutInputs.months.value = months;
  if (timeoutInputs.days) timeoutInputs.days.value = days;
  if (timeoutInputs.hours) timeoutInputs.hours.value = hours;
  if (timeoutInputs.minutes) timeoutInputs.minutes.value = minutes;
  if (timeoutInputs.seconds) timeoutInputs.seconds.value = remaining;

  updateCommandPreview();
}

function buildCommand(action) {
  const username = dashboardState.selectedUser;
  const selectedMessage = getSelectedMessage();
  const reason = actionReasonInput?.value?.trim() || "";

  if (!username) return "";

  if (action === "ban") {
    return `/ban ${username}${reason ? ` ${reason}` : ""}`;
  }

  if (action === "timeout") {
    return `/timeout ${username} ${getTimeoutSeconds()}${reason ? ` ${reason}` : ""}`;
  }

  if (action === "delete") {
    return selectedMessage
      ? `Delete selected message from ${username}: "${selectedMessage.message}"`
      : "Select a message first";
  }

  if (action === "report") {
    return selectedMessage
      ? `Report ${username} for selected message: "${selectedMessage.message}"`
      : `Report ${username} manually via Twitch user card`;
  }

  if (action === "pin") {
    return selectedMessage
      ? `Pin selected message from ${username}: "${selectedMessage.message}"`
      : "Select a message first";
  }

  if (action === "ignore") {
    return `Ignore ${username} locally`;
  }

  if (action === "automod-approve") {
    return selectedMessage
      ? `Approve AutoMod message from ${username}: "${selectedMessage.message}"`
      : "Approve selected AutoMod message later via Twitch API";
  }

  if (action === "automod-deny") {
    return selectedMessage
      ? `Deny AutoMod message from ${username}: "${selectedMessage.message}"`
      : "Deny selected AutoMod message later via Twitch API";
  }

  return "";
}

function updateCommandPreview() {
  if (!commandPreviewOutput) return;
  commandPreviewOutput.textContent = buildCommand("timeout") || "/timeout username 600";
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    setStatusKey("statusCommandCopied");
  } catch {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
    setStatusKey("statusCommandCopied");
  }
}

function addActionLog(action, command) {
  const selectedMessage = getSelectedMessage();

  const entry = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    action,
    command,
    username: dashboardState.selectedUser,
    selectedMessageId: selectedMessage?.id || null,
    selectedMessageText: selectedMessage?.message || "",
    channel: dashboardState.activeChannelData?.activeChannel || "",
    timestamp: new Date().toISOString()
  };

  dashboardState.actionLog.unshift(entry);

  if (dashboardState.actionLog.length > 100) {
    dashboardState.actionLog.pop();
  }

  saveActionLog();
  renderActionLog();
}

function renderActionLog() {
  if (!actionLogElement) return;

  if (dashboardState.actionLog.length === 0) {
    actionLogElement.innerHTML = `<div class="empty-state">${escapeHtml(t("noActionsYet"))}</div>`;
    return;
  }

  actionLogElement.innerHTML = dashboardState.actionLog
    .map((entry) => {
      const time = new Date(entry.timestamp).toLocaleTimeString(
        dashboardState.language === "de" ? "de-DE" : "en-US",
        { hour: "2-digit", minute: "2-digit", second: "2-digit" }
      );

      const messageHtml = entry.selectedMessageText
        ? `<code>${escapeHtml(entry.selectedMessageText)}</code>`
        : "";

      return `
        <div class="action-log-entry">
          <strong>${escapeHtml(time)} · ${escapeHtml(entry.action)} · ${escapeHtml(entry.username || "")}</strong>
          <code>${escapeHtml(entry.command)}</code>
          ${messageHtml}
        </div>
      `;
    })
    .join("");
}

function renderActionPanel() {
  if (!actionEmpty || !actionContent) return;

  if (!dashboardState.selectedUser) {
    actionEmpty.classList.remove("hidden");
    actionContent.classList.add("hidden");
    return;
  }

  actionEmpty.classList.add("hidden");
  actionContent.classList.remove("hidden");

  actionSelectedUsernameElement.textContent = dashboardState.selectedUser;

  const selectedMessage = getSelectedMessage();
  actionSelectedMessageState.textContent = selectedMessage
    ? selectedMessage.message.slice(0, 40)
    : "-";

  updateCommandPreview();
}

async function prepareAction(action) {
  if (!dashboardState.selectedUser && action !== "shoutout") return;

  const command = buildCommand(action);
  const needsMessage = action === "delete" || action === "pin";

  if (needsMessage && !getSelectedMessage()) {
    updateStatus(t("selectedMessageEmpty"));
    return;
  }

  if (action === "ignore") {
    addActionLog("ignore", command);
    setStatusKey("statusUserIgnored");
    return;
  }

  if (
    action === "delete" ||
    action === "report" ||
    action === "pin" ||
    action === "automod-approve" ||
    action === "automod-deny"
  ) {
    addActionLog(action, command);
    setStatusKey("statusActionPrepared");
    return;
  }

  await copyText(command);
  addActionLog(action, command);
}

function addMessage(message) {
  if (!message?.id) return;
  if (dashboardState.messages.some((item) => item.id === message.id)) return;

  dashboardState.messages.unshift(message);

  if (dashboardState.messages.length > dashboardState.maxMessages) {
    dashboardState.messages.pop();
  }

  renderMessages();
  renderSelectedMessagePanel();
  renderUserAnalysis();
  renderActionPanel();
  setStatusKey("statusLive");
}

function loadDashboardState() {
  chrome.runtime.sendMessage(
    { type: "GET_DASHBOARD_STATE", tabId: TARGET_TAB_ID },
    (response) => {
      if (!response) {
        setStatusKey("statusWaiting");
        return;
      }

      updateActiveChat(response);
      updateStreamInfo(response.streamInfo);
      updateAdInfo(response.adInfo);

      dashboardState.messages = response.messages || [];

      renderMessages();
      renderSelectedMessagePanel();
      renderUserAnalysis();
      renderActionPanel();

      setStatusKey(dashboardState.messages.length > 0 ? "statusLoaded" : "statusReady");
    }
  );
}

function setupTabs() {
  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const target = button.getAttribute("data-tab");

      tabButtons.forEach((tabButton) => tabButton.classList.remove("active"));
      tabContents.forEach((content) => content.classList.remove("active"));

      button.classList.add("active");

      const targetContent = document.getElementById(`tab-${target}`);
      if (targetContent) {
        targetContent.classList.add("active");
      }
    });
  });
}

function setupCollapsiblePanels() {
  chrome.storage.local.get(STORAGE_COLLAPSE_KEY, (result) => {
    const collapsedPanels = result[STORAGE_COLLAPSE_KEY] || {};

    document.querySelectorAll(".panel[data-collapse-key]").forEach((panel) => {
      const key = panel.getAttribute("data-collapse-key");
      const titleRow = panel.querySelector(".panel-title-row");

      if (!key || !titleRow || titleRow.querySelector(".collapse-button")) return;

      const button = document.createElement("button");
      button.className = "collapse-button";
      button.type = "button";

      if (collapsedPanels[key]) {
        panel.classList.add("collapsed");
        button.textContent = "+";
      } else {
        button.textContent = "−";
      }

      button.addEventListener("click", () => {
        panel.classList.toggle("collapsed");

        const isCollapsed = panel.classList.contains("collapsed");
        button.textContent = isCollapsed ? "+" : "−";

        collapsedPanels[key] = isCollapsed;

        chrome.storage.local.set({
          [STORAGE_COLLAPSE_KEY]: collapsedPanels
        });
      });

      titleRow.appendChild(button);
    });
  });
}

setupTabs();

if (languageSelect) {
  languageSelect.addEventListener("change", (event) => saveLanguage(event.target.value));
}

if (contentModeSelect) {
  contentModeSelect.addEventListener("change", (event) => saveContentMode(event.target.value));
}

if (dragCheckbox) {
  dragCheckbox.addEventListener("change", (event) => saveDragSetting(event.target.checked));
}

if (resetPositionButton) {
  resetPositionButton.addEventListener("click", resetLogoPosition);
}

if (clearSelectedUserButton) {
  clearSelectedUserButton.addEventListener("click", clearSelectedUser);
}

if (clearSelectedMessageButton) {
  clearSelectedMessageButton.addEventListener("click", clearSelectedMessage);
}

if (saveUserNoteButton) {
  saveUserNoteButton.addEventListener("click", saveUserNote);
}

if (copySelectedMessageButton) {
  copySelectedMessageButton.addEventListener("click", async () => {
    const selectedMessage = getSelectedMessage();
    if (!selectedMessage) return;

    await copyText(selectedMessage.message);
    setStatusKey("statusMessageCopied");
  });
}

document.querySelectorAll(".action-button[data-action]").forEach((button) => {
  button.addEventListener("click", () => prepareAction(button.getAttribute("data-action")));
});

document.querySelectorAll(".preset-button[data-timeout]").forEach((button) => {
  button.addEventListener("click", () => setTimeoutFromSeconds(Number(button.getAttribute("data-timeout"))));
});

Object.values(timeoutInputs).forEach((input) => {
  if (input) {
    input.addEventListener("input", updateCommandPreview);
  }
});

if (actionReasonInput) {
  actionReasonInput.addEventListener("input", updateCommandPreview);
}

if (copyTimeoutCommandButton) {
  copyTimeoutCommandButton.addEventListener("click", () => prepareAction("timeout"));
}

if (sendTimeoutActionButton) {
  sendTimeoutActionButton.addEventListener("click", () => prepareAction("timeout"));
}

if (clearActionLogButton) {
  clearActionLogButton.addEventListener("click", () => {
    dashboardState.actionLog = [];
    saveActionLog();
    renderActionLog();
  });
}

if (useSelectedUserShoutoutButton) {
  useSelectedUserShoutoutButton.addEventListener("click", async () => {
    if (!dashboardState.selectedUser) return;

    const username = String(dashboardState.selectedUser)
      .replace("@", "")
      .trim();

    if (!username) return;

    if (shoutoutUsernameInput) {
      shoutoutUsernameInput.value = username;
    }

    const command = `/shoutout ${username}`;

    await copyText(command);
    addActionLog("shoutout", command);
  });
}

if (copyShoutoutCommandButton) {
  copyShoutoutCommandButton.addEventListener("click", async () => {
    const username = String(shoutoutUsernameInput?.value || "")
      .replace("@", "")
      .trim();

    if (!username) return;

    const command = `/shoutout ${username}`;

    await copyText(command);
    addActionLog("shoutout", command);
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (!message?.type) return;
  if (message.tabId !== TARGET_TAB_ID) return;

  if (message.type === "DASHBOARD_ACTIVE_CHANNEL_UPDATE") updateActiveChat(message.payload);
  if (message.type === "DASHBOARD_STREAM_INFO_UPDATE") updateStreamInfo(message.payload);
  if (message.type === "DASHBOARD_AD_INFO_UPDATE") updateAdInfo(message.payload);
  if (message.type === "DASHBOARD_CHAT_MESSAGE") addMessage(message.payload);
});

loadLanguage();
loadContentMode();
loadDragSetting();
loadUserNotes();
loadActionLog();
loadDashboardState();
setupCollapsiblePanels();